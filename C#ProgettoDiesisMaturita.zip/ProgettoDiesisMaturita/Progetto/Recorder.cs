﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Diagnostics;
using System.Collections;
using Microsoft.VisualBasic;
using System.Runtime.InteropServices;

namespace Progetto
{
    public partial class Recorder : Form
    {

        Timer timer;

        public Recorder()
        {
            InitializeComponent();
            timer = new Timer(); //INIZIALIZZO IL TIMER!
        }

        private void Recorder_BackButton_Click(object sender, EventArgs e)
        {
            Menu form = new Menu();
            form.Show();
            this.Hide();
        }

        [DllImport("winmm.dll", EntryPoint = "mciSendStringA", ExactSpelling = true, CharSet = CharSet.Ansi, SetLastError = true)]
        private static extern int record(string lpstrCommand, string lpstrReturnString, int uReturnLength, int hwndCallback);


        private void Recorder_RecButton_Click(object sender, EventArgs e)
        {
            
            timer.Enabled = true;
            timer.Start();

           

            record("open new Type waveaudio Alias recsound", "", 0, 0);
            record("record recsound", "", 0, 0);
        }

        private void Recorder_StopButton_Click(object sender, EventArgs e)
        {
            
            timer.Stop();
            timer.Enabled = false;
            string cmd = "save recsound RegistrazioneDiesis"+"DATA/UTENTE"+".wav";
            record(cmd, "", 0, 0);
            record("close recsound", "", 0, 0);
        }

        /*
            lblhur.Text = "00";
            lblmin.Text = "00";
            lblsecond.Text = "00";
            */
    }
}
