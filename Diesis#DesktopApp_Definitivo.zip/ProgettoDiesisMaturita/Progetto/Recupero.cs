﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Progetto
{
    public partial class Recupero : Form
    {
        public Recupero()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
              string result = Connessione.ws.RecuperoPsw(Connessione.key, textBox_Email.Text);  //richiamo il web method del recupero password.
            if (result == "nulla") //non c'è l'email sul db
                label_errorEmail.Text = "E-mail non trovata!";
            if(result == "ok")
                MessageBox.Show("E-mail trovata", "E-mail di recupero inviata!", MessageBoxButtons.OK);//messaggio di 
            Accesso form = new Accesso();
            form.Show();
            this.Hide();
        }

        private void Recupero_BackButton_Click(object sender, EventArgs e)
        {
           
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Accesso form = new Accesso();
            form.Show();
            this.Hide();

        }
    }
}
