﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Progetto
{
    public class Connessione
    {
        public static ServiceReferenceWinServerLanzi.Service1SoapClient ws;
        public static string key;

        public Connessione()
        {
             ws = new ServiceReferenceWinServerLanzi.Service1SoapClient();
            key = "Unaacaso1997-";
        }


    }
}
