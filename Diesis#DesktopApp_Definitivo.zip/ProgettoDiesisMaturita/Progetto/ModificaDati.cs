﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Progetto
{
    public partial class ModificaDati : Form
    {
        public ModificaDati()
        {
            InitializeComponent();
        }

        private void modificaDati_BackButton_Click(object sender, EventArgs e)
        {
        }

        private void pictureBox1_Click(object sender, EventArgs e)  //Back to  Menu
        {

            Menu form = new Menu();
            form.Show();
            this.Hide();
        }

        private void modificaDati_ModificaEmailButton_Click(object sender, EventArgs e)
        {
            string result = Connessione.ws.CambioEml(Connessione.key, Utente.username, textBox_oldEmail.Text, textBox_newEmail.Text);
            if (result == "ok")
            {
                MessageBox.Show("La tua E-mail è stata cambiata!", "Cambio E-mail completato", MessageBoxButtons.OK);//messaggio di ok
                label_errorChangeMail.Text = "";
            }
            else if (result == "nulla")
                label_errorChangeMail.Text = "Errore, controlla i dati";

        }

        private void modificaDati_ModificaPasswordButton_Click(object sender, EventArgs e)
        {
            if (textBox_newPsw1.Text == textBox_newPsw2.Text) //faccio solo se le due password coincidono altrimenti no. 
            {
                string result = Connessione.ws.CambioPsw(Connessione.key, Utente.username, textBox_oldPsw.Text, textBox_newPsw1.Text);
                if (result == "ok")
                {
                    MessageBox.Show("E-mail peril cambio password inviata", "Cambio Password", MessageBoxButtons.OK);//messaggio di ok
                    label_errorChangePsw.Text = "";
                }
                else if (result == "nulla")
                    label_errorChangePsw.Text = "Errore, controlla i dati";
            }
            else
                MessageBox.Show("La tua password non è stata cambiata!", "Password non coincidenti", MessageBoxButtons.OK);//messaggio di ok
        }
    }
}
