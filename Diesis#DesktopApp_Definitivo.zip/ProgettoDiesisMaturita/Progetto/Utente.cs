﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Progetto
{
   public class Utente
    {
     public  static  string username;

        public Utente()
        {
            username = "";
        }

       public Utente(string usn)
        {
            username = usn;
        }

        public void setUsn(string usn)
        {
            username = usn;
        }
        

        public string getUsn()
        {
            return username;
        }
        

        



    }
}
