﻿using Progetto;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Progetto
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
          
        }
        

        //Overload del costruttore
        private void Menu_Load(object sender, EventArgs e)
        {
            label_Hi.Text = "Hi, " + Utente.username;
        }

        //EX BOTTONI della GUI obsoleta

        private void menu_RecorderButton_Click(object sender, EventArgs e)
        {
        }

        private void menu_ModificaDatiButton_Click(object sender, EventArgs e)
        {
        }

        private void menu_VisualizzaButton_Click(object sender, EventArgs e)
        {
        }

        //FINE EX BOTTONI

        private void pictureBox_Recorder_Click(object sender, EventArgs e)  //Registratore
        {
            Recorder form = new Recorder();
            form.Show();
            this.Hide();
        }

        private void pictureBox2_Click(object sender, EventArgs e)  //Manage Account
        {

            ModificaDati form = new ModificaDati();
            form.Show();
            this.Hide();
        }

        private void pictureBox4_Click(object sender, EventArgs e) //Visualizza Tag
        {

            Visualizza form = new Visualizza();
            form.Show();
            this.Hide();
        }

        private void menu_LogoutButton_Click(object sender, EventArgs e)
        {
            Accesso form = new Accesso();
            form.Show();
            this.Hide();
        }
    }
}
