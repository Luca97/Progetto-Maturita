﻿namespace Progetto
{
    partial class Accesso
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Accesso));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_usn = new System.Windows.Forms.TextBox();
            this.textBox_psw = new System.Windows.Forms.TextBox();
            this.Accesso_AccediButton = new System.Windows.Forms.Button();
            this.Accesso_RegistratiButton = new System.Windows.Forms.Button();
            this.Accesso_DimenticatoButton = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label_errorLogin = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 70F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label1.Location = new System.Drawing.Point(546, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(300, 107);
            this.label1.TabIndex = 0;
            this.label1.Text = "Login:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label2.Location = new System.Drawing.Point(344, 217);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(276, 63);
            this.label2.TabIndex = 1;
            this.label2.Text = "Username";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label3.Location = new System.Drawing.Point(344, 277);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(264, 63);
            this.label3.TabIndex = 2;
            this.label3.Text = "Password";
            // 
            // textBox_usn
            // 
            this.textBox_usn.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_usn.Location = new System.Drawing.Point(620, 226);
            this.textBox_usn.Name = "textBox_usn";
            this.textBox_usn.Size = new System.Drawing.Size(285, 53);
            this.textBox_usn.TabIndex = 3;
            // 
            // textBox_psw
            // 
            this.textBox_psw.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_psw.Location = new System.Drawing.Point(620, 286);
            this.textBox_psw.Name = "textBox_psw";
            this.textBox_psw.PasswordChar = '•';
            this.textBox_psw.Size = new System.Drawing.Size(285, 53);
            this.textBox_psw.TabIndex = 4;
            // 
            // Accesso_AccediButton
            // 
            this.Accesso_AccediButton.BackColor = System.Drawing.SystemColors.Info;
            this.Accesso_AccediButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Accesso_AccediButton.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.Accesso_AccediButton.Location = new System.Drawing.Point(631, 368);
            this.Accesso_AccediButton.Name = "Accesso_AccediButton";
            this.Accesso_AccediButton.Size = new System.Drawing.Size(258, 82);
            this.Accesso_AccediButton.TabIndex = 10;
            this.Accesso_AccediButton.Text = "ACCEDI";
            this.Accesso_AccediButton.UseVisualStyleBackColor = false;
            this.Accesso_AccediButton.Click += new System.EventHandler(this.Accesso_AccediButton_Click);
            // 
            // Accesso_RegistratiButton
            // 
            this.Accesso_RegistratiButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Accesso_RegistratiButton.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.Accesso_RegistratiButton.Location = new System.Drawing.Point(698, 537);
            this.Accesso_RegistratiButton.Name = "Accesso_RegistratiButton";
            this.Accesso_RegistratiButton.Size = new System.Drawing.Size(140, 40);
            this.Accesso_RegistratiButton.TabIndex = 11;
            this.Accesso_RegistratiButton.Text = "Registrati";
            this.Accesso_RegistratiButton.UseVisualStyleBackColor = true;
            this.Accesso_RegistratiButton.Click += new System.EventHandler(this.Accesso_RegistratiButton_Click);
            // 
            // Accesso_DimenticatoButton
            // 
            this.Accesso_DimenticatoButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Accesso_DimenticatoButton.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.Accesso_DimenticatoButton.Location = new System.Drawing.Point(620, 583);
            this.Accesso_DimenticatoButton.Name = "Accesso_DimenticatoButton";
            this.Accesso_DimenticatoButton.Size = new System.Drawing.Size(295, 42);
            this.Accesso_DimenticatoButton.TabIndex = 12;
            this.Accesso_DimenticatoButton.Text = "Dimenticato Password";
            this.Accesso_DimenticatoButton.UseVisualStyleBackColor = true;
            this.Accesso_DimenticatoButton.Click += new System.EventHandler(this.Accesso_DimenticatoButton_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(68, 170);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(282, 280);
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // label_errorLogin
            // 
            this.label_errorLogin.AutoSize = true;
            this.label_errorLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_errorLogin.ForeColor = System.Drawing.Color.Red;
            this.label_errorLogin.Location = new System.Drawing.Point(598, 464);
            this.label_errorLogin.Name = "label_errorLogin";
            this.label_errorLogin.Size = new System.Drawing.Size(0, 46);
            this.label_errorLogin.TabIndex = 14;
            // 
            // Accesso
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Info;
            this.ClientSize = new System.Drawing.Size(1350, 729);
            this.Controls.Add(this.label_errorLogin);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Accesso_DimenticatoButton);
            this.Controls.Add(this.Accesso_RegistratiButton);
            this.Controls.Add(this.Accesso_AccediButton);
            this.Controls.Add(this.textBox_psw);
            this.Controls.Add(this.textBox_usn);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Accesso";
            this.Text = "Accesso";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_usn;
        private System.Windows.Forms.TextBox textBox_psw;
        private System.Windows.Forms.Button Accesso_AccediButton;
        private System.Windows.Forms.Button Accesso_RegistratiButton;
        private System.Windows.Forms.Button Accesso_DimenticatoButton;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label_errorLogin;
    }
}