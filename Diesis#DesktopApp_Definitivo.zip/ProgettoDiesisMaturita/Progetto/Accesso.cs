﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Progetto
{
    public partial class Accesso : Form
    {
        public Accesso()
        {
            InitializeComponent();
          
        }

        private void Accesso_AccediButton_Click(object sender, EventArgs e)
        {
            string Usn = textBox_usn.Text;
            string Psw = textBox_psw.Text;

            Utente utente;
             string result = Connessione.ws.Autenticazione(Connessione.key, Usn, Psw);

            if ( result == "ok") //è loggato
            {
                utente = new Utente(Usn);
                Menu form = new Menu();
                form.Show();
                this.Close();
            }
            else if(result=="nulla")
                label_errorLogin.Text = "Wrong username or password";


        }

        private void Accesso_RegistratiButton_Click(object sender, EventArgs e)
        {
            RegistrazioneUtente form = new RegistrazioneUtente();
            form.Show();
            this.Hide();

        }

        private void Accesso_DimenticatoButton_Click(object sender, EventArgs e)
        {
            Recupero form = new Recupero();
            form.Show();
            this.Hide();
        }
    }
}
