﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Progetto
{
    
    public partial class Visualizza : Form
    {
        List<string[]> listaData = new List<string[]>();  //dichiaro una lista di array di string! (perché mi servono per la visualizzazione sul datagrid!)

        public Visualizza()
        {
            InitializeComponent();
           
        }

        private void Visualizza_BackButton_Click(object sender, EventArgs e)
        {
           
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Menu form = new Menu();
            form.Show();
            this.Hide();
        }

        private void Visualizza_Load(object sender, EventArgs e)
        {

            //Carico i dati in tabella: 
            List<string> lista; //dal web service mi arriva la lista di string 
            lista = Connessione.ws.MieiTag(Connessione.key, Utente.username);

                //dal web service avrei potuto farmi arrivare direttamente una Lista<string[]> però il web service non è in grado di ritornare questo oggetto :(
                //di conseguenza provvedo ora a convertire da list<string> a list<string[]> nelle prossime righe:

             
                for (int i = 0; i < lista.Count; i++)//per ogni record
                {
                       listaData.Add(  lista[i].Split('-')  );    //lista[i].Split('-') restituisce un vettore di string. Quindi aggiungo un array di string alla lista!
                }

                DataTable tabella = ConvertListToDataTable(listaData);  //utilizzo il metdodo trovato in internet per mettere la list<string[]> in una tabella (DataTable)!

                dataGridView1.DataSource = tabella;

                dataGridView1.Columns[0].HeaderText = "Genere";
                dataGridView1.Columns[1].HeaderText = "Data";
                dataGridView1.Columns[2].HeaderText = "Titolo";
                dataGridView1.Columns[3].HeaderText = "Link";
                dataGridView1.Columns[4].HeaderText = "Pubblico";
                dataGridView1.AutoResizeColumns();
                dataGridView1.AutoResizeRows();




            //Carico la lista dei generi per il filtro
            comboBox1.Items.Add("All");
            for (int i=0; i<listaData.Count; i++)
                    comboBox1.Items.Add(listaData[i][0]);  //vado a prendere il primo valore di ogni elemento della listaData.
            
                    

        }

        static DataTable ConvertListToDataTable(List<string[]> list)
        {
            // New table.
            DataTable table = new DataTable();

            // Get max columns.
            int columns = 0;
            foreach (var array in list)
            {
                if (array.Length > columns)
                {
                    columns = array.Length;
                }
            }

            // Add columns.
            for (int i = 0; i < columns; i++)
            {
                table.Columns.Add();
            }

            // Add rows.
            foreach (var array in list)
            {
                table.Rows.Add(array);
            }

            return table;
        }

        private void pictureBox_SearchGenere_Click(object sender, EventArgs e)
        {
            List<string[]> filtrati = new List<string[]>();
            if (comboBox1.Text != "All")
            {
                for (int i = 0; i < listaData.Count; i++)
                    if (listaData[i][0] == comboBox1.Text)
                        filtrati.Add(listaData[i]);

                DataTable tabella = ConvertListToDataTable(filtrati);  //utilizzo il metdodo trovato in internet per mettere la list<string[]> in una tabella (DataTable)!
                dataGridView1.DataSource = tabella;
            }
            else
            {
                //se il combo box è "All" metto nella tabella la listaData richiesta all'inizio al web service. 
                DataTable tabella = ConvertListToDataTable(listaData);  //utilizzo il metdodo trovato in internet per mettere la list<string[]> in una tabella (DataTable)!
                dataGridView1.DataSource = tabella;
            }
        }

        private void pictureBox_SearchName_Click(object sender, EventArgs e)
        {
            List<string[]> filtrati = new List<string[]>();
            if (textBox_Search.Text != "")
            {
                for (int i = 0; i < listaData.Count; i++)
                    if (listaData[i][2] == textBox_Search.Text)  //guardo il 3° campo (titolo) 
                        filtrati.Add(listaData[i]);

                DataTable tabella = ConvertListToDataTable(filtrati);  //utilizzo il metdodo trovato in internet per mettere la list<string[]> in una tabella (DataTable)!
                dataGridView1.DataSource = tabella;
            }
            else
            {
                //se il combo box è "All" metto nella tabella la listaData richiesta all'inizio al web service. 
                DataTable tabella = ConvertListToDataTable(listaData);  //utilizzo il metdodo trovato in internet per mettere la list<string[]> in una tabella (DataTable)!
                dataGridView1.DataSource = tabella;
            }

        }
    }

    
}
