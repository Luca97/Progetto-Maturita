﻿namespace Progetto
{
    partial class ModificaDati
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ModificaDati));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_oldPsw = new System.Windows.Forms.TextBox();
            this.textBox_newPsw1 = new System.Windows.Forms.TextBox();
            this.textBox_newPsw2 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label_errorChangeMail = new System.Windows.Forms.Label();
            this.modificaDati_ModificaEmailButton = new System.Windows.Forms.Button();
            this.textBox_newEmail = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_oldEmail = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.modificaDati_ModificaPasswordButton = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label_errorChangePsw = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 77);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(194, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "Vecchia E-Mail";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(238, 31);
            this.label2.TabIndex = 1;
            this.label2.Text = "Vecchia Password";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(39, 115);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(220, 31);
            this.label3.TabIndex = 2;
            this.label3.Text = "Nuova Password";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(39, 160);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(220, 31);
            this.label4.TabIndex = 3;
            this.label4.Text = "Nuova Password";
            // 
            // textBox_oldPsw
            // 
            this.textBox_oldPsw.Location = new System.Drawing.Point(294, 63);
            this.textBox_oldPsw.Name = "textBox_oldPsw";
            this.textBox_oldPsw.PasswordChar = '•';
            this.textBox_oldPsw.Size = new System.Drawing.Size(246, 38);
            this.textBox_oldPsw.TabIndex = 4;
            // 
            // textBox_newPsw1
            // 
            this.textBox_newPsw1.Location = new System.Drawing.Point(294, 111);
            this.textBox_newPsw1.Name = "textBox_newPsw1";
            this.textBox_newPsw1.PasswordChar = '•';
            this.textBox_newPsw1.Size = new System.Drawing.Size(246, 38);
            this.textBox_newPsw1.TabIndex = 5;
            // 
            // textBox_newPsw2
            // 
            this.textBox_newPsw2.Location = new System.Drawing.Point(294, 159);
            this.textBox_newPsw2.Name = "textBox_newPsw2";
            this.textBox_newPsw2.PasswordChar = '•';
            this.textBox_newPsw2.Size = new System.Drawing.Size(246, 38);
            this.textBox_newPsw2.TabIndex = 6;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label_errorChangeMail);
            this.groupBox1.Controls.Add(this.modificaDati_ModificaEmailButton);
            this.groupBox1.Controls.Add(this.textBox_newEmail);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.textBox_oldEmail);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(22, 143);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(650, 400);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Modifica E-Mail Address";
            // 
            // label_errorChangeMail
            // 
            this.label_errorChangeMail.AutoSize = true;
            this.label_errorChangeMail.ForeColor = System.Drawing.Color.Red;
            this.label_errorChangeMail.Location = new System.Drawing.Point(273, 178);
            this.label_errorChangeMail.Name = "label_errorChangeMail";
            this.label_errorChangeMail.Size = new System.Drawing.Size(0, 31);
            this.label_errorChangeMail.TabIndex = 12;
            // 
            // modificaDati_ModificaEmailButton
            // 
            this.modificaDati_ModificaEmailButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("modificaDati_ModificaEmailButton.BackgroundImage")));
            this.modificaDati_ModificaEmailButton.Location = new System.Drawing.Point(242, 224);
            this.modificaDati_ModificaEmailButton.Name = "modificaDati_ModificaEmailButton";
            this.modificaDati_ModificaEmailButton.Size = new System.Drawing.Size(130, 125);
            this.modificaDati_ModificaEmailButton.TabIndex = 11;
            this.modificaDati_ModificaEmailButton.UseVisualStyleBackColor = true;
            this.modificaDati_ModificaEmailButton.Click += new System.EventHandler(this.modificaDati_ModificaEmailButton_Click);
            // 
            // textBox_newEmail
            // 
            this.textBox_newEmail.Location = new System.Drawing.Point(270, 126);
            this.textBox_newEmail.Name = "textBox_newEmail";
            this.textBox_newEmail.Size = new System.Drawing.Size(304, 38);
            this.textBox_newEmail.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(51, 126);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(176, 31);
            this.label5.TabIndex = 9;
            this.label5.Text = "Nuova E-mail";
            // 
            // textBox_oldEmail
            // 
            this.textBox_oldEmail.Location = new System.Drawing.Point(270, 70);
            this.textBox_oldEmail.Name = "textBox_oldEmail";
            this.textBox_oldEmail.Size = new System.Drawing.Size(304, 38);
            this.textBox_oldEmail.TabIndex = 8;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label_errorChangePsw);
            this.groupBox2.Controls.Add(this.modificaDati_ModificaPasswordButton);
            this.groupBox2.Controls.Add(this.textBox_newPsw2);
            this.groupBox2.Controls.Add(this.textBox_newPsw1);
            this.groupBox2.Controls.Add(this.textBox_oldPsw);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(685, 143);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(650, 400);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Modifica Password";
            // 
            // modificaDati_ModificaPasswordButton
            // 
            this.modificaDati_ModificaPasswordButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("modificaDati_ModificaPasswordButton.BackgroundImage")));
            this.modificaDati_ModificaPasswordButton.Location = new System.Drawing.Point(294, 244);
            this.modificaDati_ModificaPasswordButton.Name = "modificaDati_ModificaPasswordButton";
            this.modificaDati_ModificaPasswordButton.Size = new System.Drawing.Size(130, 125);
            this.modificaDati_ModificaPasswordButton.TabIndex = 12;
            this.modificaDati_ModificaPasswordButton.UseVisualStyleBackColor = true;
            this.modificaDati_ModificaPasswordButton.Click += new System.EventHandler(this.modificaDati_ModificaPasswordButton_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 100);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 14;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label_errorChangePsw
            // 
            this.label_errorChangePsw.AutoSize = true;
            this.label_errorChangePsw.ForeColor = System.Drawing.Color.Red;
            this.label_errorChangePsw.Location = new System.Drawing.Point(288, 202);
            this.label_errorChangePsw.Name = "label_errorChangePsw";
            this.label_errorChangePsw.Size = new System.Drawing.Size(0, 31);
            this.label_errorChangePsw.TabIndex = 13;
            // 
            // ModificaDati
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Info;
            this.ClientSize = new System.Drawing.Size(1350, 729);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "ModificaDati";
            this.Text = "ModificaDati";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_oldPsw;
        private System.Windows.Forms.TextBox textBox_newPsw1;
        private System.Windows.Forms.TextBox textBox_newPsw2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button modificaDati_ModificaEmailButton;
        private System.Windows.Forms.TextBox textBox_newEmail;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox_oldEmail;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button modificaDati_ModificaPasswordButton;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label_errorChangeMail;
        private System.Windows.Forms.Label label_errorChangePsw;
    }
}