﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Progetto
{

   


    public partial class Benvenuto : Form
    {

        public Benvenuto()
        {
            InitializeComponent();
            Connessione connection = new Connessione();   
        }

        public object Integer { get; private set; }

        private void Benvenuto_Load(object sender, EventArgs e)
        {
           /* Accesso form = new Accesso();
            form.Show();
            Hide();
            */
        }


        private void label1_Click(object sender, EventArgs e)
        {
            Accesso form = new Accesso();
            form.Show();
            this.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

            Accesso form = new Accesso();
            form.Show();
            this.Hide();
        }
    }
}
