﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;

namespace Progetto
{
    public partial class RegistrazioneUtente : Form
    {
        public RegistrazioneUtente()
        {
            InitializeComponent();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            textBox4.UseSystemPasswordChar = true;
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            textBox5.UseSystemPasswordChar = true;
        }
        

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Accesso form = new Accesso();
            form.Show();
            this.Hide();

        }

        private void button1_Click(object sender, EventArgs e)  //REGISTRAZIONE
        {
            String username = textBox1.Text; //recupera stringa usn dall'interfaccia
            String email = textBox2.Text; //recupera stringa e-mail dall'interfaccia
            String password = textBox4.Text; //recupera stringa psw dall'interfaccia
            String confermaPassword = textBox5.Text; //recupera stringa conferma psw dall'interfaccia
            String nome = textBox_nome.Text;
            String cognome = textBox_cognome.Text;


           bool passwordOK = false; //variabile per il controllo tra psw e conferma psw




            if (password != confermaPassword)
            {
                MessageBox.Show("Riprova a digitare le password!!!", "LE PASSWORD NON CORRISPONDONO!!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);//messaggio di errore sull'inugualianza delle password
                textBox4.Text = "";
                textBox5.Text = "";
            }
            else
                passwordOK = true;

            if (passwordOK) //se psw e email corrispoindono allora richiamo il web method
            {
                string result = Connessione.ws.Registrazione(Connessione.key,email, username, password,nome,cognome);
                
                if (result == "nousn") //usn già usato
                    label_errorUsn.Text = "Username già utilizzato!";
                if (result == "noeml")//email già usato
                    label_errorEmail.Text = "E-mail già utilizzata!";
                if (result == "ok")
                {
                    label_errorEmail.Text = "";
                    label_errorUsn.Text = "";
                    MessageBox.Show("Le credenziali vanno bene!!!", "PROCEDURA D'ISCRIZIONE AVVIATA!!!", MessageBoxButtons.OK);//messaggio di ok
                }
            }  
        }



        private void button4_Click(object sender, EventArgs e)
        {



        }

        private void Registrazione_BackButton_Click(object sender, EventArgs e)
        {

        }

       
    }
}
