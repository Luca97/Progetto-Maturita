﻿namespace Progetto
{
    partial class Recorder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Recorder));
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textBox_BPM = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox_Record = new System.Windows.Forms.PictureBox();
            this.pictureBox_Stop = new System.Windows.Forms.PictureBox();
            this.label_record = new System.Windows.Forms.Label();
            this.label_stop = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.button_cancel = new System.Windows.Forms.Button();
            this.button_send = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_Genere = new System.Windows.Forms.TextBox();
            this.textBox_Titolo = new System.Windows.Forms.TextBox();
            this.checkBox_public = new System.Windows.Forms.CheckBox();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Record)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Stop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.textBox_BPM);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.ForeColor = System.Drawing.Color.Navy;
            this.groupBox4.Location = new System.Drawing.Point(368, 353);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(155, 95);
            this.groupBox4.TabIndex = 4;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "BPM";
            // 
            // textBox_BPM
            // 
            this.textBox_BPM.Location = new System.Drawing.Point(29, 37);
            this.textBox_BPM.Name = "textBox_BPM";
            this.textBox_BPM.Size = new System.Drawing.Size(100, 38);
            this.textBox_BPM.TabIndex = 2;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.ForeColor = System.Drawing.Color.Navy;
            this.groupBox3.Location = new System.Drawing.Point(988, 353);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(320, 95);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Durata Traccia";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label1.Location = new System.Drawing.Point(69, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "00:00:00";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 100);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox_Record
            // 
            this.pictureBox_Record.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_Record.Image")));
            this.pictureBox_Record.Location = new System.Drawing.Point(572, 318);
            this.pictureBox_Record.Name = "pictureBox_Record";
            this.pictureBox_Record.Size = new System.Drawing.Size(150, 150);
            this.pictureBox_Record.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_Record.TabIndex = 7;
            this.pictureBox_Record.TabStop = false;
            this.pictureBox_Record.Click += new System.EventHandler(this.pictureBox_Record_Click);
            // 
            // pictureBox_Stop
            // 
            this.pictureBox_Stop.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_Stop.Image")));
            this.pictureBox_Stop.Location = new System.Drawing.Point(769, 318);
            this.pictureBox_Stop.Name = "pictureBox_Stop";
            this.pictureBox_Stop.Size = new System.Drawing.Size(150, 150);
            this.pictureBox_Stop.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_Stop.TabIndex = 8;
            this.pictureBox_Stop.TabStop = false;
            this.pictureBox_Stop.Visible = false;
            this.pictureBox_Stop.Click += new System.EventHandler(this.pictureBox_Stop_Click);
            // 
            // label_record
            // 
            this.label_record.AutoSize = true;
            this.label_record.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_record.Location = new System.Drawing.Point(589, 471);
            this.label_record.Name = "label_record";
            this.label_record.Size = new System.Drawing.Size(133, 31);
            this.label_record.TabIndex = 9;
            this.label_record.Text = "RECORD";
            // 
            // label_stop
            // 
            this.label_stop.AutoSize = true;
            this.label_stop.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_stop.Location = new System.Drawing.Point(801, 471);
            this.label_stop.Name = "label_stop";
            this.label_stop.Size = new System.Drawing.Size(88, 31);
            this.label_stop.TabIndex = 10;
            this.label_stop.Text = "STOP";
            this.label_stop.Visible = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(557, 22);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(727, 251);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 11;
            this.pictureBox2.TabStop = false;
            // 
            // button_cancel
            // 
            this.button_cancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_cancel.Location = new System.Drawing.Point(728, 518);
            this.button_cancel.Name = "button_cancel";
            this.button_cancel.Size = new System.Drawing.Size(102, 48);
            this.button_cancel.TabIndex = 12;
            this.button_cancel.Text = "Annulla";
            this.button_cancel.UseVisualStyleBackColor = true;
            this.button_cancel.Visible = false;
            this.button_cancel.Click += new System.EventHandler(this.button_cancel_Click);
            // 
            // button_send
            // 
            this.button_send.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_send.Location = new System.Drawing.Point(845, 518);
            this.button_send.Name = "button_send";
            this.button_send.Size = new System.Drawing.Size(102, 48);
            this.button_send.TabIndex = 13;
            this.button_send.Text = "Invia";
            this.button_send.UseVisualStyleBackColor = true;
            this.button_send.Visible = false;
            this.button_send.Click += new System.EventHandler(this.button_send_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkBox_public);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.textBox_Genere);
            this.groupBox1.Controls.Add(this.textBox_Titolo);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Navy;
            this.groupBox1.Location = new System.Drawing.Point(23, 295);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(329, 235);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "INFO";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 118);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 31);
            this.label3.TabIndex = 3;
            this.label3.Text = "Genere:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 31);
            this.label2.TabIndex = 2;
            this.label2.Text = "Titolo:";
            // 
            // textBox_Genere
            // 
            this.textBox_Genere.Location = new System.Drawing.Point(129, 115);
            this.textBox_Genere.Name = "textBox_Genere";
            this.textBox_Genere.Size = new System.Drawing.Size(184, 38);
            this.textBox_Genere.TabIndex = 1;
            // 
            // textBox_Titolo
            // 
            this.textBox_Titolo.Location = new System.Drawing.Point(129, 46);
            this.textBox_Titolo.Name = "textBox_Titolo";
            this.textBox_Titolo.Size = new System.Drawing.Size(184, 38);
            this.textBox_Titolo.TabIndex = 0;
            // 
            // checkBox_public
            // 
            this.checkBox_public.AutoSize = true;
            this.checkBox_public.Location = new System.Drawing.Point(99, 175);
            this.checkBox_public.Name = "checkBox_public";
            this.checkBox_public.Size = new System.Drawing.Size(137, 35);
            this.checkBox_public.TabIndex = 4;
            this.checkBox_public.Text = "Pubblico";
            this.checkBox_public.UseVisualStyleBackColor = true;
            // 
            // Recorder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Info;
            this.ClientSize = new System.Drawing.Size(1350, 729);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button_send);
            this.Controls.Add(this.button_cancel);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label_stop);
            this.Controls.Add(this.label_record);
            this.Controls.Add(this.pictureBox_Stop);
            this.Controls.Add(this.pictureBox_Record);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox3);
            this.Name = "Recorder";
            this.Text = "Recorder";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Record)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Stop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox textBox_BPM;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox_Record;
        private System.Windows.Forms.PictureBox pictureBox_Stop;
        private System.Windows.Forms.Label label_record;
        private System.Windows.Forms.Label label_stop;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button button_cancel;
        private System.Windows.Forms.Button button_send;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBox_Genere;
        private System.Windows.Forms.TextBox textBox_Titolo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox checkBox_public;
    }
}