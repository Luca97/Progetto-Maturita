﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace metronome
{

    public partial class Accesso : Form
    {
        public Accesso()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

            String username = textBox4.Text; //recupera stringa usn dall'interfaccia
            String password = textBox3.Text; //recupera stringa psw dall'interfaccia
            String email = textBox5.Text; //recupera stringa e-mail dall'interfaccia

            String confermaPassword = textBox6.Text; //recupera stringa conferma_psw dall'interfaccia
            String confermaEmail = textBox7.Text; //recupera stringa conferma e-mail dall'interfaccia

            if (password != confermaPassword) //se password è diversa da conferma_password
            {
                MessageBox.Show("Riprova a digitare le password!!!", "LE PASSWORD NON CORRISPONDONO!!!", MessageBoxButtons.OK, MessageBoxIcon.Warning); //finestra di errore sulla psw 
                button4.ForeColor = Color.Red; //testo bottone rosso
                textBox3.Text = ""; //azzeramento del campo
                textBox7.Text = ""; //azzeramento del campo
            }
            if (email != confermaEmail) //se password è diversa da conferma_email
            {
                MessageBox.Show("Riprova a digitare le email!!!", "LE E-MAIL NON CORRISPONDONO!!!", MessageBoxButtons.OK, MessageBoxIcon.Warning); //finestra di errore sulla e-mail
                button4.ForeColor = Color.Red; //testo bottone rosso
                textBox5.Text = ""; //azzeramento campo
                textBox6.Text = ""; //azzeramento campo
            }

            bool trovato = false; //variabile booleana per la ricerca dell'utente 
            

            string[] lines = System.IO.File.ReadAllLines(@"C:\Users\Luca\Documents\file a caso\metronome\Utenti.txt"); //copia il file nel vettore: ogni riga corrisponde ad un elemento

            foreach (string s in lines)//ciclo per scorrere tutto il vettore
            {
                int i = 0;
                string[] split = lines[i].Split(";".ToCharArray());//splitta ogni riga negli elementi del vettore split

                if (split[0] == username)//se usn e password corrispondono
                {
                    trovato = true;//setta trovato = true
                    break;//interrompe il foreach
                }
                i++;
            }


            if (trovato == true)//se trovato è true
            {
                button4.ForeColor = Color.Red; //colora di rosso la scritta del bottone
                MessageBox.Show("Scegli un'altro username!!!", "USERNAME OCCUPATA!!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);//finestra di errore sulla registrazione
                textBox4.Text = "";
            }
            else if (trovato == false) //se trovato è false
            {
                button4.ForeColor = Color.Green;//colora di verde la scritta del bottone

                using (StreamWriter w = File.AppendText(@"C:\Users\Luca\Documents\file a caso\metronome\Utenti.txt"))
                {
                    w.WriteLine(username+";"+password+";"+email);
                }

                MessageBox.Show("Le credenziali andavano bene!!!", "CREDENZIALI ACCETTATE!!!", MessageBoxButtons.OK);//finestra di errore sulla login
                
            }




        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            textBox3.PasswordChar = '*';
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox2.PasswordChar = '*';//nasconde i caratteri con *
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String usn = textBox1.Text; //recupera stringa usn dall'interfaccia
            String psw = textBox2.Text; //recupera stringa psw dall'interfaccia
            bool trovato = false; //variabile booleana per la ricerca dell'utente 

            string[] lines = System.IO.File.ReadAllLines(@"C:\Users\Luca\Documents\file a caso\metronome\Utenti.txt"); //copia il file nel vettore: ogni riga corrisponde ad un elemento

            foreach(string s in lines)//ciclo per scorrere tutto il vettore
            {
                int i = 0;
                string[] split = lines[i].Split(";".ToCharArray());//splitta ogni riga negli elementi del vettore split
                
                if(split[0] == usn && split[1] == psw)//se usn e password corrispondono
                {
                    trovato = true;//setta trovato = true
                    break;//interrompe il foreach
                }
                i++;
            }

            if (trovato == true)//se trovato è true
            {
                button1.ForeColor = Color.Green; //colora di verde la scritta del bottone
                Programma form = new Programma();
                form.Show();//mostra la finestra Programma
                this.Hide();//nasconde la finestra Accesso
            }
            else if(trovato == false) //se trovato è false
            {
                button1.ForeColor = Color.Red;//colora di rosso la scritta del bottone
                MessageBox.Show("Riprova a digitare le credenziali!!!", "PASSWORD O USERNAME NON TROVATI!!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);//finestra di errore sulla login
                
            }



        }

        private void button2_Click(object sender, EventArgs e)
        {
            button2.ForeColor = Color.Blue;//colora di blu la scritta
            Recupero_Credenziali form = new Recupero_Credenziali();
            form.Show();//mostra la finestra di recupero dati
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            textBox6.PasswordChar = '*';//nasconde i caratteri con *
        }
    }
}
