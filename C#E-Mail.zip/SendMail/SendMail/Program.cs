﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Mail;
using System.Net;

namespace SendMail
{
    class Program
    {
        static void Main(string[] args)
        {
            SmtpClient smtpClient = new SmtpClient();
            NetworkCredential basicCredential = new NetworkCredential("zireael.info@gmail.com", "06021997Lucaf6-");
            MailMessage message = new MailMessage();
            MailAddress fromAddress = new MailAddress("zireael.info@gmail.com");

            smtpClient.Host = "smtp.gmail.com";
            smtpClient.UseDefaultCredentials = false;
            smtpClient.Credentials = basicCredential;
            smtpClient.Port = 587;
            smtpClient.EnableSsl = true;

            message.From = fromAddress;
            message.Subject = "LANZIIIIIIII FUNZIONAAAAAAAAAA";
            //Set IsBodyHtml to true means you can send HTML email.
            message.IsBodyHtml = true;
            message.Body = "<h1>Lanziiii guarda tra le notifiche!!!!!!!!!</h1>";
            message.To.Add("andrea.lanzi2013@gmail.com");
            message.Priority = MailPriority.High;

            try
            {
                smtpClient.Send(message);
            }
            catch (Exception ex)
            {
                //Error, could not send the message
                Console.Write(ex);
                Console.ReadLine();
            }

            

        }
    }
}
