﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MySql.Data.MySqlClient;
using MySql.Data;
namespace RubricaWebServer
{
    public class sql
    {
        public static string[] cerca (string nome)
        
        {
            List<string> data = new List<string>();
            int i=0;
            string[] ritorno=new string[10];
            string connStr = "server=localhost;user=root;database=rubrica;port=3306;password=;";
            
            MySqlDataReader rdr = null;
            try
            {
                MySqlConnection conn = new MySqlConnection(connStr);
                conn.Open();

               // string sql = "INSERT INTO `contatti` (`ID`, `Nome`, `email`, `Tel`) VALUES (NULL, 'xxx', 'xxx', 'xxx');";
                string sql = "SELECT * FROM `contatti` WHERE nome='"+nome+"'";
                MySqlCommand cmd = new MySqlCommand(sql, conn);

                //script.Error += new MySqlScriptErrorEventHandler(script_Error);
                //script.ScriptCompleted += new EventHandler(script_ScriptCompleted);
                //script.StatementExecuted += new MySqlStatementExecutedEventHandler(script_StatementExecuted);

                rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    data.Add(rdr.GetInt32(0) + "-"
                        + rdr.GetString(1) + "-" + rdr.GetString(2));
                    
                }
                


                conn.Close();
            }
            catch (Exception ex)
            {
                data.Add( "errore") ; 
            }

            
            

            return data.ToArray();
            
            
            
            
        }
    }
}