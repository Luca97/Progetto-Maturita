﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CercaAuto.rubrica;
namespace CercaAuto
{
    public partial class Form1 : Form
    {
        private WebService1SoapClient ws = new WebService1SoapClient();
        public Form1()
        {
            InitializeComponent();
            pictureBox1.BackColor = Color.Yellow;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listView1.Clear();
            CercaAuto.rubrica.ArrayOfString r=new ArrayOfString();
         
            r  = ws.ricerca(textBox1.Text);
            var items = listView1.Items;
           
            foreach (var value in r)
            {
                items.Add(value);
            }
            if (items.Count == 0)
                pictureBox1.BackColor = Color.Red;
            else
                pictureBox1.BackColor = Color.Green;

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string s = listView1.SelectedItems[0].Text;
            string[] words = s.Split('-');
            label1.Text = words[0];
            label2.Text = words[1];
            label3.Text = words[2];
            label1.Text = words[3];
            
        }
    }
}
