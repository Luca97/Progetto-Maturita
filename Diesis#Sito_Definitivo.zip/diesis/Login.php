<?php 
session_start();
if(isset($_SESSION["username"]))
		echo header("location: manageCr.php");
?>
		

<?php $_POST["pagina"]="login.php"; $_POST["titolo"]="Login"; $_POST["src"]="js/chkLogin.js"; $_POST["srcPopup"]="js/popup.js"; $_POST["srcQuery"]="js/jquery.js"; include "layout/headEsterni.php";?>


<body>
    <!-- Navigation -->
	 <?php $_POST["pagina"]="login.php"; include "layout/navbarEsterni.php"; ?>

    <!-- Page Content -->
	
	<div id="boxes">
		<div id="dialog" class="window">
			BENVENUTO!</br>
			Questa e' la versione web di Diesis#</br>
			Attraverso questo portale potrai accedere usando gli stessi dati dell'applicazione web</br>
			o decidere di registrarti per la prima volta!</br>
			Una volta eseguito l'accesso potrai visionare i tuoi spartiti e quelli pubblici degli altri utenti
			oltre che gestire il tuo profilo</br>
			Pronto?
			<div id="popupfoot"> <a href="#" class="close agree">INIZIAMO!</a></div>
		</div>
		<div id="mask"></div>
	</div>
    <div class="container">
	
	<div id="immagine">
			<img src="logo.png" style="width: 350px;height: 200px;">
	</div>
	<form class="form" action="chkLogin.php" method="POST">
			<input type="text" name="username" id="username" placeholder="username"/><br/></br>
			<input type="password" name="password" id="password" placeholder="password"/><br/><br/>
			<input id="login" type="submit" value="Login" onclick="return chkLogin();">
			<br/>Non sei ancora iscritto? <a href="verifica.php">Registrati!</a>
			<br/>Hai dimenticato la password? <a href="dimenticoPassword.php">Recuperala!</a>
	</form>
    </div>
	
    <!-- /.container -->

    <!-- jQuery Version 1.11.1 -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
	
</body>
</html><!--Chiude il tag aperto dall'head-->
