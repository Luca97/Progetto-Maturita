<?php $_POST["pagina"]="contact.php"; $_POST["titolo"]="Contatti"; $_POST["src"]=""; include "layout/headEsterni.php";?>


<body>
    <img>http://cornerstonevidalia.com/wp-content/uploads/2013/06/Welcome-Page.png</img>
	
</body>

</html>