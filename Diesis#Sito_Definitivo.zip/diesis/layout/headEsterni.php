<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
	<script type="text/javascript" src="js/popup.js"></script>
	<script src="js/jquery.js"></script>
	<script type="text/javascript" src="<?php echo $_POST["src"];?>"></script>
	<?php
	if(isset($_POST["srcPopup"]) && isset($_POST["srcQuery"]))
	{
		$srcPopup=$_POST['srcPopup'];
		$srcQuery=$_POST['srcQuery'];
		echo "
				<script type='text/javascript' src='$srcPopup'></script>
				<script type='text/javascript' src='$srcQuery'></script>";
	}
	?>
	
    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min2.css" rel="stylesheet">
	<link href="css/popup.css" rel="stylesheet">
	<link rel="icon" type="image/png" href="logo.ico">
	
	<title><?php echo $_POST["titolo"];?></title>    
	<!-- Custom CSS -->
    <style>
    body {
        padding-top: 70px;
        /* Required padding for .navbar-fixed-top. Remove if using .navbar-static-top. Change if height of navigation changes. */
    }
    </style>
</head>