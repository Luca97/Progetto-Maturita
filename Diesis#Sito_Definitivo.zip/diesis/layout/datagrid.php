<div class="container" style="overflow-x:auto;">

<div id="immagine">
	<!--<img src="logo.png" style="width:200;">-->
</div>
<form class="form" action=<?php echo $_POST['pagina']; ?> method="POST">
	<h1><?php echo $_POST["h1"];//Titolo pagina ?></h1>
	<h2><?php echo "Genere"; ?></h2> 
	
	<!--Non serve includere la classe elementClass poich� ci pensa gi� la pagina chiamante, si avrebbe un override-->
	<?php $db1 = new dbClass; $el= new elementClass; $el->printSelect($db1); ?>
	<input class="button" type="submit" value="Filtra"/>
	
	<h2><?php echo "Titolo"; ?></h2> 
	<input type="text" name="nome" id="nome" placeholder="Filtrare per titolo"/><br/></br>
	<input class="button" type="submit" value="Cerca"/>
	
	<?php 
		//Il nome del file datagrid, deriva dal fatto che il div delle tabelle si chiama datagrid
		//Non serve includere la classe elementClass poich� ci pensa gi� la pagina chiamante, si avrebbe un override
		$vInfo2=array("Titolo","Genere","Data creazione","Link","Autore");
		
		if(isset($_POST["utente"]) || $_POST['pagina']=="visualizza.php")//Vuol dire che la pagina chiamante � profiloUtente.php quindi non stampo l'autore
			$vInfo2=array("Titolo","Genere","Data creazione","Link");
		else
			$vInfo2=$vInfo2;
		
		$el->printDatagrid($vInfo2,$ar);
	
	?>

</div>
<!-- /.container -->

<!-- jQuery Version 1.11.1 -->
<script src="js/jquery.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>